﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace SE.PL
{
    public partial class HomePage : Form
    {
        private int imageNumber = 1;

        private void loadNextImage()
        {
            if (imageNumber == 3)
            {
                imageNumber = 1;
            }
            picboxHomeAdd.Load(string.Format(@".\Images\logo{0}.jpg", imageNumber));
            imageNumber++;
        }
        public HomePage()
        {
            InitializeComponent();
        }

        private void btnAddToCart_Click(object sender, EventArgs e)
        {

        }

        private void HomePage_Load(object sender, EventArgs e)
        {

        }

        private void HomePage_Activated(object sender, EventArgs e)
        {
            if (Login.user != null)
            {
                lblUser.Text = Login.user;
                lblUser.Visible = true;
                linlabLogOut.Visible = true;
                linlabLogin.Visible = false;
            }
            else
            {
                linlabLogin.Visible = true;
            }

        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            loadNextImage();
        }

        private void linlabLogin_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            Login lg = new Login();
            lg.Show();
        }

        private void linlabLogOut_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            MessageBox.Show("Logged Out");
            this.txtHADesc.SelectTab("tpHome");
            Login.user = null;
            lblUser.Text = "";
            linlabLogOut.Visible = false;
            linlabLogin.Visible = true;
        }

        private void btnElecAddToCart_Click(object sender, EventArgs e)
        {
            if (lblUser.Text == "")
            {
                Login lg = new Login();
                lg.Show();
            }
            else
            {
                panelElecCart.Visible = true;
            }
        }
    }
}
