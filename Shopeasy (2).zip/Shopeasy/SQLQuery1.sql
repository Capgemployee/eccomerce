﻿Create Schema [EC]

CREATE TABLE [EC].[Category]
(
	[Category Id] INT NOT NULL PRIMARY KEY, 
    [Category Name] NVARCHAR(MAX) NOT NULL, 
    [Category Description] NVARCHAR(MAX) NOT NULL
)

CREATE TABLE [EC].[Product Desc]
(
	[Product Desc ID] INT NOT NULL PRIMARY KEY, 
    [Product Desc] NVARCHAR(MAX) NOT NULL, 
    [Date Of Modification] DATETIME NOT NULL
)

CREATE TABLE [EC].[Customer]
(
	[Customer Id] INT NOT NULL , 
    [Customer First Name] NVARCHAR(MAX) NOT NULL, 
    [Customer Last Name] NVARCHAR(MAX) NOT NULL, 
    [Address Room No.] NVARCHAR(MAX) NOT NULL, 
    [Address Building] NVARCHAR(MAX) NOT NULL, 
    [Address City] NVARCHAR(MAX) NOT NULL, 
    [Address State] NVARCHAR(MAX) NOT NULL, 
    [Address Pincode] NVARCHAR(MAX) NOT NULL, 
    [Email ID] NVARCHAR(MAX) NOT NULL, 
    [Mobile No.] NVARCHAR(50) NOT NULL, 
    [User ID] NVARCHAR(50) NOT NULL, 
    [Password] NVARCHAR(MAX) NOT NULL, 
    [Billing Address Room No.] NVARCHAR(MAX) NOT NULL, 
    [Billing Address Building] NVARCHAR(MAX) NOT NULL, 
    [Billing Address City] NVARCHAR(MAX) NOT NULL, 
    [Billing Address State] NVARCHAR(MAX) NOT NULL, 
    [Billing Address Pincode] NVARCHAR(50) NOT NULL, 
    CONSTRAINT [PK_Customer] PRIMARY KEY ([Customer Id]) 
);


CREATE TABLE [EC].[Order] (
    [Order ID]       INT          NOT NULL,
    [Order Date]     DATETIME     NOT NULL,
    [Required Date]  DATETIME     NOT NULL,
    [Ship Date]      DATETIME     NOT NULL,
    [Payment Status] BIT          NOT NULL,
    [Shipper ID]     INT          NOT NULL,
    [Order Status]   BIT          NOT NULL,
    [Customer ID]    INT          NOT NULL,
    [Price]          INT          NOT NULL,
    [Discount]       DECIMAL (18) NOT NULL,
    [Total]          DECIMAL (18) NOT NULL,
    [Bill Date]      DATETIME     NOT NULL,
    [Product ID1]    INT          NOT NULL,
    [Product ID2]    INT          NOT NULL,
    [Product ID3]    INT          NOT NULL,
    [Product ID4]    INT          NOT NULL,
    [Product ID5]    INT          NOT NULL,
    PRIMARY KEY CLUSTERED ([Order ID] ASC),
    CONSTRAINT [FK_Order_Customer] FOREIGN KEY ([Customer ID]) REFERENCES [EC].[Customer] ([Customer Id]), 
    CONSTRAINT [FK_Order_Product] FOREIGN KEY ([Product ID1]) REFERENCES [EC].[Product]([Product ID]), 
    CONSTRAINT [FK_Order_Product1] FOREIGN KEY ([Product ID2]) REFERENCES [EC].[Product]([Product ID]), 
    CONSTRAINT [FK_Order_Product2] FOREIGN KEY ([Product ID3]) REFERENCES [EC].[Product]([Product ID]), 
    CONSTRAINT [FK_Order_Product3] FOREIGN KEY ([Product ID4]) REFERENCES [EC].[Product]([Product ID]), 
    CONSTRAINT [FK_Order_Product4] FOREIGN KEY ([Product ID5]) REFERENCES [EC].[Product]([Product ID]), 
);



CREATE TABLE [EC].[Supplier]
(
	[Supplier ID] INT NOT NULL PRIMARY KEY, 
    [Comapany Name] NVARCHAR(MAX) NOT NULL, 
    [Address 1] NVARCHAR(MAX) NOT NULL, 
    [Address 2] NVARCHAR(MAX) NOT NULL, 
    [City] NVARCHAR(MAX) NOT NULL, 
    [State] NVARCHAR(MAX) NOT NULL, 
    [Postal Code] NVARCHAR(MAX) NOT NULL, 
    [Mobile No] NVARCHAR(50) NOT NULL, 
    [Email ID] NVARCHAR(50) NOT NULL, 
    [Web Site] NVARCHAR(50) NOT NULL, 
    [Logo] IMAGE NOT NULL, 
    [Ranking] INT NOT NULL, 
    [Note] NVARCHAR(MAX) NOT NULL
);

CREATE TABLE [EC].[Product]
(
	[Product ID] INT NOT NULL , 
    [Product Name] NVARCHAR(50) NOT NULL, 
    [Product Desc ID] INT NOT NULL, 
    [Supplier ID] INT NOT NULL, 
    [Category Id] INT NOT NULL, 
    [Units] INT NOT NULL, 
    [Unit Price] INT NOT NULL, 
    [MRP] INT NOT NULL, 
    [Discount] DECIMAL NOT NULL, 
    [Picture] IMAGE NOT NULL, 
    [Ranking] INT NOT NULL, 
    [Note] NVARCHAR(MAX) NOT NULL, 
    CONSTRAINT [PK_Product] PRIMARY KEY ([Product ID]), 
    CONSTRAINT [FK_Product_ProductDesc] FOREIGN KEY ([Product Desc ID]) REFERENCES  [EC].[Product Desc]([Product Desc ID]), 
    CONSTRAINT [FK_Product_Supplier] FOREIGN KEY ([Supplier ID]) REFERENCES [EC].[Supplier]([Supplier ID]), 
    CONSTRAINT [FK_Product_Category] FOREIGN KEY ([Category Id]) REFERENCES [EC].[Category]([Category Id]) 
)



