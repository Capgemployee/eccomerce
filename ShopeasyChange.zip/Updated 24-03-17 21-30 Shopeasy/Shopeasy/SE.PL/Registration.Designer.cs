﻿namespace SE.PL
{
    partial class Registration
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Registration));
            this.panelOReg = new System.Windows.Forms.Panel();
            this.panelIReg = new System.Windows.Forms.Panel();
            this.txtCPass = new System.Windows.Forms.TextBox();
            this.btnRegister = new System.Windows.Forms.Button();
            this.txtPass = new System.Windows.Forms.TextBox();
            this.txtUID = new System.Windows.Forms.TextBox();
            this.txtMobile = new System.Windows.Forms.TextBox();
            this.txtEmail = new System.Windows.Forms.TextBox();
            this.txtLName = new System.Windows.Forms.TextBox();
            this.txtFName = new System.Windows.Forms.TextBox();
            this.lblCPass = new System.Windows.Forms.Label();
            this.lblPass = new System.Windows.Forms.Label();
            this.lblUID = new System.Windows.Forms.Label();
            this.lblMobile = new System.Windows.Forms.Label();
            this.lblEmail = new System.Windows.Forms.Label();
            this.lblLName = new System.Windows.Forms.Label();
            this.lblFName = new System.Windows.Forms.Label();
            this.lblCreateAcc = new System.Windows.Forms.Label();
            this.panelOReg.SuspendLayout();
            this.panelIReg.SuspendLayout();
            this.SuspendLayout();
            // 
            // panelOReg
            // 
            this.panelOReg.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.panelOReg.Controls.Add(this.panelIReg);
            this.panelOReg.Location = new System.Drawing.Point(118, 48);
            this.panelOReg.Name = "panelOReg";
            this.panelOReg.Size = new System.Drawing.Size(948, 667);
            this.panelOReg.TabIndex = 1;
            // 
            // panelIReg
            // 
            this.panelIReg.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.panelIReg.Controls.Add(this.txtCPass);
            this.panelIReg.Controls.Add(this.btnRegister);
            this.panelIReg.Controls.Add(this.txtPass);
            this.panelIReg.Controls.Add(this.txtUID);
            this.panelIReg.Controls.Add(this.txtMobile);
            this.panelIReg.Controls.Add(this.txtEmail);
            this.panelIReg.Controls.Add(this.txtLName);
            this.panelIReg.Controls.Add(this.txtFName);
            this.panelIReg.Controls.Add(this.lblCPass);
            this.panelIReg.Controls.Add(this.lblPass);
            this.panelIReg.Controls.Add(this.lblUID);
            this.panelIReg.Controls.Add(this.lblMobile);
            this.panelIReg.Controls.Add(this.lblEmail);
            this.panelIReg.Controls.Add(this.lblLName);
            this.panelIReg.Controls.Add(this.lblFName);
            this.panelIReg.Controls.Add(this.lblCreateAcc);
            this.panelIReg.Location = new System.Drawing.Point(138, 46);
            this.panelIReg.Name = "panelIReg";
            this.panelIReg.Size = new System.Drawing.Size(697, 548);
            this.panelIReg.TabIndex = 1;
            // 
            // txtCPass
            // 
            this.txtCPass.Location = new System.Drawing.Point(281, 352);
            this.txtCPass.Name = "txtCPass";
            this.txtCPass.PasswordChar = '*';
            this.txtCPass.Size = new System.Drawing.Size(266, 20);
            this.txtCPass.TabIndex = 14;
            // 
            // btnRegister
            // 
            this.btnRegister.Font = new System.Drawing.Font("Times New Roman", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnRegister.Location = new System.Drawing.Point(281, 426);
            this.btnRegister.Name = "btnRegister";
            this.btnRegister.Size = new System.Drawing.Size(89, 29);
            this.btnRegister.TabIndex = 0;
            this.btnRegister.Text = "Register";
            this.btnRegister.UseVisualStyleBackColor = true;
            this.btnRegister.Click += new System.EventHandler(this.btnRegister_Click);
            // 
            // txtPass
            // 
            this.txtPass.Location = new System.Drawing.Point(281, 306);
            this.txtPass.Name = "txtPass";
            this.txtPass.PasswordChar = '*';
            this.txtPass.Size = new System.Drawing.Size(266, 20);
            this.txtPass.TabIndex = 13;
            // 
            // txtUID
            // 
            this.txtUID.Location = new System.Drawing.Point(281, 264);
            this.txtUID.Name = "txtUID";
            this.txtUID.Size = new System.Drawing.Size(266, 20);
            this.txtUID.TabIndex = 12;
            // 
            // txtMobile
            // 
            this.txtMobile.Location = new System.Drawing.Point(281, 225);
            this.txtMobile.Name = "txtMobile";
            this.txtMobile.Size = new System.Drawing.Size(266, 20);
            this.txtMobile.TabIndex = 11;
            // 
            // txtEmail
            // 
            this.txtEmail.Location = new System.Drawing.Point(281, 181);
            this.txtEmail.Name = "txtEmail";
            this.txtEmail.Size = new System.Drawing.Size(266, 20);
            this.txtEmail.TabIndex = 10;
            // 
            // txtLName
            // 
            this.txtLName.Location = new System.Drawing.Point(281, 135);
            this.txtLName.Name = "txtLName";
            this.txtLName.Size = new System.Drawing.Size(266, 20);
            this.txtLName.TabIndex = 9;
            // 
            // txtFName
            // 
            this.txtFName.Location = new System.Drawing.Point(281, 94);
            this.txtFName.Name = "txtFName";
            this.txtFName.Size = new System.Drawing.Size(266, 20);
            this.txtFName.TabIndex = 8;
            // 
            // lblCPass
            // 
            this.lblCPass.AutoSize = true;
            this.lblCPass.Font = new System.Drawing.Font("Times New Roman", 12F);
            this.lblCPass.Location = new System.Drawing.Point(126, 356);
            this.lblCPass.Name = "lblCPass";
            this.lblCPass.Size = new System.Drawing.Size(122, 19);
            this.lblCPass.TabIndex = 7;
            this.lblCPass.Text = "Confirm Password";
            // 
            // lblPass
            // 
            this.lblPass.AutoSize = true;
            this.lblPass.Font = new System.Drawing.Font("Times New Roman", 12F);
            this.lblPass.Location = new System.Drawing.Point(125, 303);
            this.lblPass.Name = "lblPass";
            this.lblPass.Size = new System.Drawing.Size(69, 19);
            this.lblPass.TabIndex = 6;
            this.lblPass.Text = "Password";
            // 
            // lblUID
            // 
            this.lblUID.AutoSize = true;
            this.lblUID.Font = new System.Drawing.Font("Times New Roman", 12F);
            this.lblUID.Location = new System.Drawing.Point(125, 260);
            this.lblUID.Name = "lblUID";
            this.lblUID.Size = new System.Drawing.Size(58, 19);
            this.lblUID.TabIndex = 5;
            this.lblUID.Text = "User ID";
            // 
            // lblMobile
            // 
            this.lblMobile.AutoSize = true;
            this.lblMobile.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblMobile.Location = new System.Drawing.Point(125, 217);
            this.lblMobile.Name = "lblMobile";
            this.lblMobile.Size = new System.Drawing.Size(142, 19);
            this.lblMobile.TabIndex = 4;
            this.lblMobile.Text = "Enter Mobile Number";
            // 
            // lblEmail
            // 
            this.lblEmail.AutoSize = true;
            this.lblEmail.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblEmail.Location = new System.Drawing.Point(125, 174);
            this.lblEmail.Name = "lblEmail";
            this.lblEmail.Size = new System.Drawing.Size(98, 19);
            this.lblEmail.TabIndex = 3;
            this.lblEmail.Text = "Enter Email ID";
            // 
            // lblLName
            // 
            this.lblLName.AutoSize = true;
            this.lblLName.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblLName.Location = new System.Drawing.Point(125, 128);
            this.lblLName.Name = "lblLName";
            this.lblLName.Size = new System.Drawing.Size(112, 19);
            this.lblLName.TabIndex = 2;
            this.lblLName.Text = "Enter Last Name";
            // 
            // lblFName
            // 
            this.lblFName.AutoSize = true;
            this.lblFName.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblFName.Location = new System.Drawing.Point(125, 91);
            this.lblFName.Name = "lblFName";
            this.lblFName.Size = new System.Drawing.Size(113, 19);
            this.lblFName.TabIndex = 1;
            this.lblFName.Text = "Enter First Name";
            // 
            // lblCreateAcc
            // 
            this.lblCreateAcc.AutoSize = true;
            this.lblCreateAcc.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.lblCreateAcc.Font = new System.Drawing.Font("Times New Roman", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblCreateAcc.Location = new System.Drawing.Point(285, 31);
            this.lblCreateAcc.Name = "lblCreateAcc";
            this.lblCreateAcc.Size = new System.Drawing.Size(139, 24);
            this.lblCreateAcc.TabIndex = 0;
            this.lblCreateAcc.Text = "Create Account";
            // 
            // Registration
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("$this.BackgroundImage")));
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.ClientSize = new System.Drawing.Size(1184, 741);
            this.Controls.Add(this.panelOReg);
            this.Cursor = System.Windows.Forms.Cursors.Help;
            this.Name = "Registration";
            this.Text = "Registration";
            this.WindowState = System.Windows.Forms.FormWindowState.Maximized;
            this.panelOReg.ResumeLayout(false);
            this.panelIReg.ResumeLayout(false);
            this.panelIReg.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel panelOReg;
        private System.Windows.Forms.Panel panelIReg;
        private System.Windows.Forms.TextBox txtCPass;
        private System.Windows.Forms.Button btnRegister;
        private System.Windows.Forms.TextBox txtPass;
        private System.Windows.Forms.TextBox txtUID;
        private System.Windows.Forms.TextBox txtMobile;
        private System.Windows.Forms.TextBox txtEmail;
        private System.Windows.Forms.TextBox txtLName;
        private System.Windows.Forms.TextBox txtFName;
        private System.Windows.Forms.Label lblCPass;
        private System.Windows.Forms.Label lblPass;
        private System.Windows.Forms.Label lblUID;
        private System.Windows.Forms.Label lblMobile;
        private System.Windows.Forms.Label lblEmail;
        private System.Windows.Forms.Label lblLName;
        private System.Windows.Forms.Label lblFName;
        private System.Windows.Forms.Label lblCreateAcc;
    }
}